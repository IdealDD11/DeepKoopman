# DeepKoopman

Package requirements: gym, mujoco, PyTorch

To test the model with pretrained weights
```
python koopmanPendulum.py --mode eval
python koopmanInvertedPendulum.py --mode eval
```
